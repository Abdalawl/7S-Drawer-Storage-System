CREATE TABLE `drawers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`drawerId` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`isDefault` boolean NOT NULL DEFAULT false,
	`userId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `drawers_id` PRIMARY KEY(`id`),
	CONSTRAINT `drawers_drawerId_unique` UNIQUE(`drawerId`)
);
--> statement-breakpoint
CREATE TABLE `items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`itemId` varchar(64) NOT NULL,
	`drawerId` int NOT NULL,
	`item` varchar(500) NOT NULL,
	`quantity` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `items_id` PRIMARY KEY(`id`),
	CONSTRAINT `items_itemId_unique` UNIQUE(`itemId`)
);
--> statement-breakpoint
ALTER TABLE `drawers` ADD CONSTRAINT `drawers_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `items` ADD CONSTRAINT `items_drawerId_drawers_id_fk` FOREIGN KEY (`drawerId`) REFERENCES `drawers`(`id`) ON DELETE no action ON UPDATE no action;