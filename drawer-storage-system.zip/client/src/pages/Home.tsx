import { useEffect, useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Package, Search, Eye, EyeOff, Copy, ChevronRight, X } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { APP_TITLE } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Home() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [showUrls, setShowUrls] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showDrawerModal, setShowDrawerModal] = useState(false);
  const [newDrawerName, setNewDrawerName] = useState("");

  const utils = trpc.useUtils();

  // Initialize default drawers
  const initMutation = trpc.drawer.initialize.useMutation();

  // Get all drawers
  const { data: drawers = [], isLoading } = trpc.drawer.list.useQuery();

  // Search items
  const { data: searchResults = [] } = trpc.search.query.useQuery(
    { query: searchQuery },
    { enabled: searchQuery.trim().length > 0 }
  );

  // Create drawer mutation
  const createDrawerMutation = trpc.drawer.create.useMutation({
    onSuccess: (data) => {
      utils.drawer.list.invalidate();
      setNewDrawerName("");
      setShowDrawerModal(false);
      toast.success("Drawer created successfully");
      setLocation(`/drawer/${data.drawerId}`);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create drawer");
    },
  });

  // Subscribe to real-time updates
  trpc.drawer.onUpdate.useSubscription(undefined, {
    onData: () => {
      utils.drawer.list.invalidate();
    },
  });

  // Initialize drawers on mount
  useEffect(() => {
    initMutation.mutate();
  }, []);

  const totalItems = useMemo(() => 
    drawers.reduce((sum, drawer) => sum + (drawer.itemsCount || 0), 0),
    [drawers]
  );

  const generateDrawerUrl = (drawerId: string) => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/drawer/${drawerId}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("URL copied to clipboard");
  };

  const handleCreateDrawer = () => {
    if (!newDrawerName.trim()) {
      toast.error("Drawer name cannot be empty");
      return;
    }

    const existingNames = drawers.map(d => d.name.toLowerCase());
    if (existingNames.includes(newDrawerName.trim().toLowerCase())) {
      toast.error("A drawer with this name already exists");
      return;
    }

    createDrawerMutation.mutate({ name: newDrawerName.trim() });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="w-12 h-12 mx-auto mb-3 text-blue-600 animate-pulse" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-6">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h1 className="text-xl sm:text-2xl font-semibold text-gray-900">{APP_TITLE}</h1>
              <p className="text-xs sm:text-sm text-gray-500 mt-1">
                {totalItems} items across {drawers.length} drawers
              </p>
            </div>
            <div className="flex gap-2 sm:gap-3">
              {drawers.length > 0 && (
                <Button
                  onClick={() => setShowUrls(!showUrls)}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  {showUrls ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  <span className="hidden sm:inline">{showUrls ? "Hide URLs" : "Show URLs"}</span>
                  <span className="sm:hidden">URLs</span>
                </Button>
              )}
              {user && (
                <Button
                  onClick={() => setShowDrawerModal(true)}
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span className="hidden sm:inline">New Drawer</span>
                  <span className="sm:hidden">New</span>
                </Button>
              )}
            </div>
          </div>

          {/* Search */}
          <div className="mt-3 sm:mt-4 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <Card>
            <CardContent className="p-3 sm:p-4">
              <h2 className="font-semibold text-gray-900 mb-3 text-sm sm:text-base">
                Search Results ({searchResults.length})
              </h2>
              <div className="space-y-2">
                {searchResults.map((result) => (
                  <div
                    key={result.itemId}
                    onClick={() => setLocation(`/drawer/${result.drawerId}`)}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-gray-900 text-sm truncate">{result.item}</div>
                      <div className="text-xs sm:text-sm text-gray-500 truncate">
                        {result.drawerName} • Qty: {result.quantity}
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0 ml-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Drawer Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
          {drawers.map((drawer) => (
            <Card
              key={drawer.drawerId}
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => setLocation(`/drawer/${drawer.drawerId}`)}
            >
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 text-base sm:text-lg truncate">
                      {drawer.name}
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-500 mt-1">
                      {drawer.itemsCount || 0} items
                    </p>
                  </div>
                  <Package className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 flex-shrink-0 ml-2" />
                </div>

                {showUrls && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={generateDrawerUrl(drawer.drawerId)}
                        readOnly
                        onClick={(e) => e.stopPropagation()}
                        className="flex-1 text-xs px-2 py-1 bg-gray-50 border border-gray-200 rounded truncate"
                      />
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          copyToClipboard(generateDrawerUrl(drawer.drawerId));
                        }}
                        className="flex-shrink-0 p-1"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {drawers.length === 0 && (
          <div className="text-center py-12">
            <Package className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <p className="text-gray-600 mb-4">No drawers yet</p>
            <Button onClick={() => initMutation.mutate()}>
              Initialize Default Drawers
            </Button>
          </div>
        )}
      </div>

      {/* Create Drawer Dialog */}
      <Dialog open={showDrawerModal} onOpenChange={setShowDrawerModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Drawer</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Input
              placeholder="Drawer name"
              value={newDrawerName}
              onChange={(e) => setNewDrawerName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateDrawer()}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDrawerModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateDrawer} disabled={createDrawerMutation.isPending}>
              {createDrawerMutation.isPending ? "Creating..." : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
