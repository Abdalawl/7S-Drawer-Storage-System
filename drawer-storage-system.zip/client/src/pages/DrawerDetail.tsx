import { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Package, ChevronLeft, Edit2, Trash2, Save, X, Download, Plus } from "lucide-react";
import { toast } from "sonner";

export default function DrawerDetail() {
  const [, params] = useRoute("/drawer/:drawerId");
  const [, setLocation] = useLocation();
  const drawerId = params?.drawerId || "";

  const [editingItem, setEditingItem] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItemName, setNewItemName] = useState("");
  const [newItemQuantity, setNewItemQuantity] = useState(1);

  const utils = trpc.useUtils();

  // Get drawer with items
  const { data: drawer, isLoading } = trpc.drawer.get.useQuery(
    { drawerId },
    { enabled: !!drawerId }
  );

  // Add item mutation
  const addItemMutation = trpc.item.add.useMutation({
    onSuccess: () => {
      utils.drawer.get.invalidate({ drawerId });
      setShowAddForm(false);
      setNewItemName("");
      setNewItemQuantity(1);
      toast.success("Item added successfully");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add item");
    },
  });

  // Update item mutation
  const updateItemMutation = trpc.item.update.useMutation({
    onSuccess: () => {
      utils.drawer.get.invalidate({ drawerId });
      setEditingItem(null);
      toast.success("Item updated successfully");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update item");
    },
  });

  // Delete item mutation
  const deleteItemMutation = trpc.item.delete.useMutation({
    onSuccess: () => {
      utils.drawer.get.invalidate({ drawerId });
      toast.success("Item deleted successfully");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete item");
    },
  });

  // Delete drawer mutation
  const deleteDrawerMutation = trpc.drawer.delete.useMutation({
    onSuccess: () => {
      toast.success("Drawer deleted successfully");
      setLocation("/");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete drawer");
    },
  });

  // Subscribe to real-time updates
  trpc.drawer.onUpdate.useSubscription(undefined, {
    onData: (data) => {
      if (data.drawerId === drawerId || data.type.startsWith('item-')) {
        utils.drawer.get.invalidate({ drawerId });
      }
    },
  });

  const handleAddItem = () => {
    if (!newItemName.trim()) {
      toast.error("Item name cannot be empty");
      return;
    }

    addItemMutation.mutate({
      drawerId,
      item: newItemName.trim(),
      quantity: newItemQuantity,
    });
  };

  const handleUpdateItem = (itemId: string, itemName: string, quantity: number) => {
    if (!itemName.trim()) {
      toast.error("Item name cannot be empty");
      return;
    }

    if (quantity < 0) {
      toast.error("Quantity must be 0 or greater");
      return;
    }

    updateItemMutation.mutate({
      itemId,
      item: itemName.trim(),
      quantity,
    });
  };

  const handleDeleteItem = (itemId: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      deleteItemMutation.mutate({ itemId });
    }
  };

  const handleDeleteDrawer = () => {
    if (confirm(`Are you sure you want to delete "${drawer?.name}"? This will also delete all items inside.`)) {
      deleteDrawerMutation.mutate({ drawerId });
    }
  };

  const exportCSV = () => {
    if (!drawer || !drawer.items) return;

    const csv = ["Item,Quantity"];
    drawer.items.forEach((item) => {
      csv.push(`"${item.item}",${item.quantity}`);
    });

    const blob = new Blob([csv.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${drawer.name.replace(/[^a-z0-9]/gi, "_")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="w-12 h-12 mx-auto mb-3 text-blue-600 animate-pulse" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!drawer) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <p className="text-gray-600">Drawer not found</p>
          <Button onClick={() => setLocation("/")} className="mt-4">
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-6">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/")}
                className="flex-shrink-0"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <div className="min-w-0">
                <h1 className="text-lg sm:text-2xl font-semibold text-gray-900 truncate">
                  {drawer.name}
                </h1>
                <p className="text-xs sm:text-sm text-gray-500 mt-1">
                  {drawer.items?.length || 0} items
                </p>
              </div>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <Button
                variant="outline"
                size="sm"
                onClick={exportCSV}
                className="flex items-center gap-1 sm:gap-2"
              >
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Export</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleDeleteDrawer}
                className="flex items-center gap-1 sm:gap-2 text-red-600 hover:bg-red-50 border-red-200"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">Delete</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {/* Table - Editable Items */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-100 border-b border-gray-200">
                  <tr>
                    <th className="text-left px-3 sm:px-6 py-2 sm:py-3 text-xs sm:text-sm font-semibold text-gray-700">
                      Item
                    </th>
                    <th className="text-left px-3 sm:px-6 py-2 sm:py-3 text-xs sm:text-sm font-semibold text-gray-700 w-20 sm:w-auto">
                      Qty
                    </th>
                    <th className="text-right px-3 sm:px-6 py-2 sm:py-3 text-xs sm:text-sm font-semibold text-gray-700 w-20 sm:w-auto">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {drawer.items?.length === 0 && !showAddForm ? (
                    <tr>
                      <td colSpan={3} className="px-3 sm:px-6 py-8 sm:py-12 text-center text-gray-400">
                        <Package className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 opacity-50" />
                        <p className="text-sm sm:text-base">No items yet</p>
                      </td>
                    </tr>
                  ) : (
                    <>
                      {drawer.items?.map((item, index) => (
                        <tr
                          key={item.itemId}
                          className={`border-b border-gray-200 hover:bg-gray-50 ${
                            index % 2 === 0 ? "bg-white" : "bg-gray-50"
                          }`}
                        >
                          {editingItem === item.itemId ? (
                            <>
                              <td className="px-3 sm:px-6 py-3 sm:py-4">
                                <Input
                                  type="text"
                                  defaultValue={item.item}
                                  id={`edit-item-${item.itemId}`}
                                  className="w-full"
                                />
                              </td>
                              <td className="px-3 sm:px-6 py-3 sm:py-4">
                                <Input
                                  type="number"
                                  defaultValue={item.quantity}
                                  id={`edit-qty-${item.itemId}`}
                                  min="0"
                                  className="w-full"
                                />
                              </td>
                              <td className="px-3 sm:px-6 py-3 sm:py-4 text-right">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => {
                                    const itemName = (
                                      document.getElementById(`edit-item-${item.itemId}`) as HTMLInputElement
                                    ).value;
                                    const qty = parseInt(
                                      (document.getElementById(`edit-qty-${item.itemId}`) as HTMLInputElement).value
                                    );
                                    handleUpdateItem(item.itemId, itemName, qty);
                                  }}
                                  className="text-green-600 hover:bg-green-50 mr-1 sm:mr-2"
                                >
                                  <Save className="w-4 h-4 sm:w-5 sm:h-5" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setEditingItem(null)}
                                  className="text-gray-600 hover:bg-gray-100"
                                >
                                  <X className="w-4 h-4 sm:w-5 sm:h-5" />
                                </Button>
                              </td>
                            </>
                          ) : (
                            <>
                              <td className="px-3 sm:px-6 py-3 sm:py-4 text-gray-900 text-sm sm:text-base">
                                {item.item}
                              </td>
                              <td className="px-3 sm:px-6 py-3 sm:py-4 text-gray-900 text-sm sm:text-base">
                                {item.quantity}
                              </td>
                              <td className="px-3 sm:px-6 py-3 sm:py-4 text-right">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setEditingItem(item.itemId)}
                                  className="text-blue-600 hover:bg-blue-50 mr-1 sm:mr-2"
                                >
                                  <Edit2 className="w-4 h-4 sm:w-5 sm:h-5" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleDeleteItem(item.itemId)}
                                  className="text-red-600 hover:bg-red-50"
                                >
                                  <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                                </Button>
                              </td>
                            </>
                          )}
                        </tr>
                      ))}
                      {showAddForm && (
                        <tr className="bg-blue-50 border-b border-gray-200">
                          <td className="px-3 sm:px-6 py-3 sm:py-4">
                            <Input
                              type="text"
                              placeholder="Item name"
                              value={newItemName}
                              onChange={(e) => setNewItemName(e.target.value)}
                              onKeyDown={(e) => e.key === "Enter" && handleAddItem()}
                              autoFocus
                            />
                          </td>
                          <td className="px-3 sm:px-6 py-3 sm:py-4">
                            <Input
                              type="number"
                              placeholder="Qty"
                              value={newItemQuantity}
                              onChange={(e) => setNewItemQuantity(parseInt(e.target.value) || 0)}
                              min="0"
                            />
                          </td>
                          <td className="px-3 sm:px-6 py-3 sm:py-4 text-right">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={handleAddItem}
                              className="text-green-600 hover:bg-green-50 mr-1 sm:mr-2"
                            >
                              <Save className="w-4 h-4 sm:w-5 sm:h-5" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                setShowAddForm(false);
                                setNewItemName("");
                                setNewItemQuantity(1);
                              }}
                              className="text-gray-600 hover:bg-gray-100"
                            >
                              <X className="w-4 h-4 sm:w-5 sm:h-5" />
                            </Button>
                          </td>
                        </tr>
                      )}
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Add Item Button */}
        {!showAddForm && (
          <Button onClick={() => setShowAddForm(true)} className="mt-4 w-full sm:w-auto">
            <Plus className="w-4 h-4 mr-2" />
            Add Item
          </Button>
        )}
      </div>
    </div>
  );
}
