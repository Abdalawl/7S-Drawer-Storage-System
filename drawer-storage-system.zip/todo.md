# Drawer Storage System TODO

## Database & Backend
- [x] Create database schema for drawers and items
- [x] Implement tRPC procedures for drawer CRUD operations
- [x] Implement tRPC procedures for item CRUD operations
- [x] Add real-time WebSocket support for live syncing
- [x] Add global search functionality

## Frontend
- [x] Build home page with drawer grid
- [x] Build drawer detail page with item management
- [x] Implement real-time updates using WebSocket
- [x] Add search functionality
- [x] Add QR code/URL display for drawer access
- [x] Add CSV export functionality
- [x] Make UI responsive for mobile devices

## Features
- [x] Support for 17 default drawers
- [x] Support for custom drawer creation
- [x] Item quantity tracking
- [x] Real-time synchronization across devices
- [x] Shareable drawer URLs

## New Features
- [x] Add delete drawer functionality with confirmation dialog
- [x] Allow deletion of all drawers (including default drawers 1-17)

## Bug Fixes
- [x] Fixed "require is not defined" error in routers.ts by replacing dynamic require with ES6 imports

## Stripe Payment Integration
- [ ] Set up Stripe API keys and webhook configuration
- [ ] Create payment products and pricing tiers
- [ ] Build checkout page and payment flow
- [ ] Implement subscription management
- [ ] Add payment history and receipts
