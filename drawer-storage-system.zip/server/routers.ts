import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { observable } from '@trpc/server/observable';
import { EventEmitter } from 'events';
import { drawers } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Event emitter for real-time updates
const ee = new EventEmitter();

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  drawer: router({
    // Initialize default drawers
    initialize: publicProcedure.mutation(async () => {
      await db.initializeDefaultDrawers();
      return { success: true };
    }),

    // Get all drawers
    list: publicProcedure.query(async ({ ctx }) => {
      const userId = ctx.user?.id;
      const drawersList = await db.getAllDrawers(userId);
      
      // Get items count for each drawer
      const drawersWithItems = await Promise.all(
        drawersList.map(async (drawer) => {
          const itemsList = await db.getItemsByDrawerId(drawer.drawerId);
          return {
            ...drawer,
            itemsCount: itemsList.length
          };
        })
      );
      
      return drawersWithItems;
    }),

    // Get single drawer with items
    get: publicProcedure
      .input(z.object({ drawerId: z.string() }))
      .query(async ({ input }) => {
        const drawer = await db.getDrawerByDrawerId(input.drawerId);
        if (!drawer) return null;

        const itemsList = await db.getItemsByDrawerId(input.drawerId);
        
        return {
          ...drawer,
          items: itemsList
        };
      }),

    // Create custom drawer
    create: protectedProcedure
      .input(z.object({ name: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const drawerId = `custom-${Date.now()}`;
        await db.createDrawer({
          drawerId,
          name: input.name,
          isDefault: false,
          userId: ctx.user.id
        });

        // Emit update event
        ee.emit('drawerUpdate', { type: 'drawer-created', drawerId });

        return { drawerId };
      }),

    // Update drawer name
    update: protectedProcedure
      .input(z.object({ 
        drawerId: z.string(),
        name: z.string().min(1)
      }))
      .mutation(async ({ input }) => {
        await db.updateDrawer(input.drawerId, input.name);
        
        // Emit update event
        ee.emit('drawerUpdate', { type: 'drawer-updated', drawerId: input.drawerId });

        return { success: true };
      }),

    // Delete drawer
    delete: protectedProcedure
      .input(z.object({ drawerId: z.string() }))
      .mutation(async ({ input }) => {
        await db.deleteDrawer(input.drawerId);
        
        // Emit update event
        ee.emit('drawerUpdate', { type: 'drawer-deleted', drawerId: input.drawerId });

        return { success: true };
      }),

    // Subscribe to drawer updates
    onUpdate: publicProcedure.subscription(() => {
      return observable<{ type: string; drawerId?: string; itemId?: string }>((emit) => {
        const onUpdate = (data: any) => {
          emit.next(data);
        };

        ee.on('drawerUpdate', onUpdate);

        return () => {
          ee.off('drawerUpdate', onUpdate);
        };
      });
    }),
  }),

  item: router({
    // Add item to drawer
    add: publicProcedure
      .input(z.object({
        drawerId: z.string(),
        item: z.string().min(1),
        quantity: z.number().min(0).default(1)
      }))
      .mutation(async ({ input }) => {
        const drawer = await db.getDrawerByDrawerId(input.drawerId);
        if (!drawer) throw new Error("Drawer not found");

        const itemId = `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        await db.createItem({
          itemId,
          drawerId: drawer.id,
          item: input.item,
          quantity: input.quantity
        });

        // Emit update event
        ee.emit('drawerUpdate', { type: 'item-added', drawerId: input.drawerId, itemId });

        return { itemId };
      }),

    // Update item
    update: publicProcedure
      .input(z.object({
        itemId: z.string(),
        item: z.string().min(1).optional(),
        quantity: z.number().min(0).optional()
      }))
      .mutation(async ({ input }) => {
        const { itemId, ...updateData } = input;
        const existingItem = await db.getItemByItemId(itemId);
        if (!existingItem) throw new Error("Item not found");

        await db.updateItem(itemId, updateData);

        // Get drawer info for event
        const drawerRecord = await db.getDb().then(d => 
          d?.select().from(drawers)
            .where(eq(drawers.id, existingItem.drawerId))
            .limit(1)
        );
        const drawerId = drawerRecord?.[0]?.drawerId || '';

        // Emit update event
        ee.emit('drawerUpdate', { type: 'item-updated', drawerId, itemId });

        return { success: true };
      }),

    // Delete item
    delete: publicProcedure
      .input(z.object({ itemId: z.string() }))
      .mutation(async ({ input }) => {
        const existingItem = await db.getItemByItemId(input.itemId);
        if (!existingItem) throw new Error("Item not found");

        // Get drawer info for event
        const drawerRecord = await db.getDb().then(d => 
          d?.select().from(drawers)
            .where(eq(drawers.id, existingItem.drawerId))
            .limit(1)
        );
        const drawerId = drawerRecord?.[0]?.drawerId || '';

        await db.deleteItem(input.itemId);

        // Emit update event
        ee.emit('drawerUpdate', { type: 'item-deleted', drawerId, itemId: input.itemId });

        return { success: true };
      }),
  }),

  search: router({
    // Global search
    query: publicProcedure
      .input(z.object({ query: z.string().min(1) }))
      .query(async ({ input, ctx }) => {
        const userId = ctx.user?.id;
        return await db.searchItems(input.query, userId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
