import { eq, and, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, drawers, items, InsertDrawer, InsertItem, Drawer, Item } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Drawer operations
export async function getAllDrawers(userId?: number) {
  const db = await getDb();
  if (!db) return [];

  if (userId) {
    return await db.select().from(drawers).where(
      or(
        eq(drawers.isDefault, true),
        eq(drawers.userId, userId)
      )
    );
  }
  
  return await db.select().from(drawers).where(eq(drawers.isDefault, true));
}

export async function getDrawerByDrawerId(drawerId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(drawers).where(eq(drawers.drawerId, drawerId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDrawer(drawer: InsertDrawer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(drawers).values(drawer);
  return result;
}

export async function updateDrawer(drawerId: string, name: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(drawers).set({ name, updatedAt: new Date() }).where(eq(drawers.drawerId, drawerId));
}

export async function deleteDrawer(drawerId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const drawer = await getDrawerByDrawerId(drawerId);
  if (!drawer) throw new Error("Drawer not found");

  // Delete all items in the drawer first
  await db.delete(items).where(eq(items.drawerId, drawer.id));
  
  // Delete the drawer
  await db.delete(drawers).where(eq(drawers.drawerId, drawerId));
}

// Item operations
export async function getItemsByDrawerId(drawerId: string) {
  const db = await getDb();
  if (!db) return [];

  const drawer = await getDrawerByDrawerId(drawerId);
  if (!drawer) return [];

  return await db.select().from(items).where(eq(items.drawerId, drawer.id));
}

export async function getItemByItemId(itemId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(items).where(eq(items.itemId, itemId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createItem(item: InsertItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(items).values(item);
  return result;
}

export async function updateItem(itemId: string, itemData: { item?: string; quantity?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(items).set({ ...itemData, updatedAt: new Date() }).where(eq(items.itemId, itemId));
}

export async function deleteItem(itemId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(items).where(eq(items.itemId, itemId));
}

// Search operations
export async function searchItems(query: string, userId?: number) {
  const db = await getDb();
  if (!db) return [];

  const searchPattern = `%${query}%`;
  
  // Get all accessible drawers
  let accessibleDrawers: Drawer[];
  if (userId) {
    accessibleDrawers = await db.select().from(drawers).where(
      or(
        eq(drawers.isDefault, true),
        eq(drawers.userId, userId)
      )
    );
  } else {
    accessibleDrawers = await db.select().from(drawers).where(eq(drawers.isDefault, true));
  }

  const drawerIds = accessibleDrawers.map(d => d.id);
  if (drawerIds.length === 0) return [];

  // Search items in accessible drawers
  const results = await db.select({
    item: items,
    drawer: drawers
  })
  .from(items)
  .leftJoin(drawers, eq(items.drawerId, drawers.id))
  .where(
    and(
      like(items.item, searchPattern),
      or(...drawerIds.map(id => eq(items.drawerId, id)))
    )
  );

  return results.map(r => ({
    ...r.item,
    drawerName: r.drawer?.name || '',
    drawerId: r.drawer?.drawerId || ''
  }));
}

// Initialize default drawers
export async function initializeDefaultDrawers() {
  const db = await getDb();
  if (!db) return;

  for (let i = 1; i <= 17; i++) {
    const drawerId = `drawer-${i}`;
    const existing = await getDrawerByDrawerId(drawerId);
    
    if (!existing) {
      await createDrawer({
        drawerId,
        name: `Drawer ${i}`,
        isDefault: true,
        userId: null
      });
    }
  }
}
